import javax.swing.*;

public class Main {

    Controller controller;


    public static void main(String[] args) {
        new Main().go();
    }
    private void go(){
        controller = new Controller();
    }
}
