import java.util.ArrayList;

public class Model {
    ArrayList<String> data;

    public Model(){
         data = new ArrayList<>();
    }
    public ArrayList<String> getData(){
        return data;
    }
    public void addData(String item){
        data.add(item);
    }
    public void removeData(String item){
        data.remove(item);
    }
}
