public interface TwoDimensional {
    public abstract double area();
    public abstract double perimeter();
}
