public interface ThreeDimensional {
     public abstract double volume();
     public abstract double surfaceArea();
}
