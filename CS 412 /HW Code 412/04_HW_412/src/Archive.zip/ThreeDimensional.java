public interface ThreeDimensional {
    double volume();
    double surfaceArea();
}
