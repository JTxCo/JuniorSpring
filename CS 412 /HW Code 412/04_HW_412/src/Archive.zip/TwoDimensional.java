public interface TwoDimensional {
double area();
double perimeter();

}
